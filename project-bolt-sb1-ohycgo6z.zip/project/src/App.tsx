import { useEffect, useState } from "react";
import { TrendingUp, Twitter, Instagram, Music } from "lucide-react";
import { supabase } from "./lib/supabase";

interface TrendingHashtag {
  id: string;
  hashtag: string;
  platform: string;
  tweet_count: number;
  engagement_rate: number;
  rank: number;
}

function App() {
  const [trendingHashtags, setTrendingHashtags] = useState<TrendingHashtag[]>([]);
  const [selectedPlatform, setSelectedPlatform] = useState<string>("all");
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);

  const platforms = [
    { id: "all", name: "All Platforms", icon: TrendingUp, color: "bg-blue-50 border-blue-200" },
    { id: "twitter", name: "Twitter/X", icon: Twitter, color: "bg-sky-50 border-sky-200" },
    { id: "instagram", name: "Instagram", icon: Instagram, color: "bg-pink-50 border-pink-200" },
    { id: "tiktok", name: "TikTok", icon: Music, color: "bg-purple-50 border-purple-200" },
  ];

  useEffect(() => {
    fetchTrendingHashtags();
    syncTrendingData();
  }, []);

  useEffect(() => {
    const subscription = supabase
      .channel("trending_changes")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "trending_hashtags",
        },
        () => {
          fetchTrendingHashtags();
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const fetchTrendingHashtags = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from("trending_hashtags")
        .select("*")
        .order("rank", { ascending: true });

      if (error) throw error;
      setTrendingHashtags(data || []);
    } catch (error) {
      console.error("Error fetching trending hashtags:", error);
    } finally {
      setLoading(false);
    }
  };

  const syncTrendingData = async () => {
    try {
      setSyncing(true);
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

      const apiUrl = `${supabaseUrl}/functions/v1/trending-hashtags?action=fetch`;

      const response = await fetch(apiUrl, {
        headers: {
          Authorization: `Bearer ${anonKey}`,
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) throw new Error("Failed to sync trending data");
      await response.json();
      await fetchTrendingHashtags();
    } catch (error) {
      console.error("Error syncing trending data:", error);
    } finally {
      setSyncing(false);
    }
  };

  const filteredHashtags =
    selectedPlatform === "all"
      ? trendingHashtags
      : trendingHashtags.filter((h) => h.platform === selectedPlatform);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800">
      <div className="max-w-6xl mx-auto px-4 py-12">
        <header className="mb-12">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <TrendingUp className="w-8 h-8 text-blue-400" />
              <h1 className="text-4xl font-bold text-white">Trending Hashtags</h1>
            </div>
            <button
              onClick={syncTrendingData}
              disabled={syncing}
              className="px-6 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white font-medium rounded-lg transition-colors"
            >
              {syncing ? "Syncing..." : "Sync Data"}
            </button>
          </div>
          <p className="text-slate-400">Real-time trending hashtags across social media platforms</p>
        </header>

        <div className="mb-8 grid grid-cols-2 md:grid-cols-4 gap-3">
          {platforms.map((platform) => {
            const Icon = platform.icon;
            const isActive = selectedPlatform === platform.id;
            return (
              <button
                key={platform.id}
                onClick={() => setSelectedPlatform(platform.id)}
                className={`p-4 rounded-lg border-2 transition-all ${
                  isActive
                    ? "border-blue-400 bg-blue-500 bg-opacity-10 text-white shadow-lg"
                    : `border-slate-700 ${platform.color} text-slate-600 hover:border-slate-500`
                }`}
              >
                <Icon className="w-5 h-5 mb-2 mx-auto" />
                <p className="text-sm font-medium">{platform.name}</p>
              </button>
            );
          })}
        </div>

        <div className="grid gap-4">
          {loading ? (
            <div className="text-center py-12">
              <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-400" />
              <p className="mt-4 text-slate-300">Loading trending hashtags...</p>
            </div>
          ) : filteredHashtags.length === 0 ? (
            <div className="text-center py-12 bg-slate-800 bg-opacity-50 rounded-lg border border-slate-700">
              <p className="text-slate-400">No trending hashtags found</p>
            </div>
          ) : (
            filteredHashtags.map((hashtag) => (
              <div
                key={hashtag.id}
                className="bg-slate-800 bg-opacity-50 border border-slate-700 rounded-lg p-6 hover:border-slate-600 transition-all hover:shadow-lg"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-4 flex-1">
                    <div className="flex-shrink-0 w-12 h-12 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white font-bold text-lg">
                      #{hashtag.rank}
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-semibold text-white hover:text-blue-400 cursor-pointer transition-colors">
                        {hashtag.hashtag}
                      </h3>
                      <p className="text-sm text-slate-400 capitalize">{hashtag.platform}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="inline-block px-3 py-1 bg-green-500 bg-opacity-20 text-green-300 rounded-full text-sm font-medium">
                      {hashtag.engagement_rate.toFixed(1)}% engagement
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-slate-900 bg-opacity-50 rounded p-3">
                    <p className="text-slate-400 text-sm mb-1">Uses/Mentions</p>
                    <p className="text-2xl font-bold text-blue-400">
                      {(hashtag.tweet_count / 1000).toFixed(1)}K
                    </p>
                  </div>

                  <div className="bg-slate-900 bg-opacity-50 rounded p-3">
                    <p className="text-slate-400 text-sm mb-1">Engagement Rate</p>
                    <p className="text-2xl font-bold text-green-400">{hashtag.engagement_rate}%</p>
                  </div>

                  <div className="bg-slate-900 bg-opacity-50 rounded p-3">
                    <p className="text-slate-400 text-sm mb-1">Rank</p>
                    <p className="text-2xl font-bold text-purple-400">#{hashtag.rank}</p>
                  </div>
                </div>

                <div className="mt-3 h-2 bg-slate-700 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-blue-500 to-purple-500"
                    style={{ width: `${Math.min((hashtag.engagement_rate / 15) * 100, 100)}%` }}
                  />
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

export default App;
