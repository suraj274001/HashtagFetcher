/*
  # Create Trending Hashtags Table

  1. New Tables
    - `trending_hashtags`
      - `id` (uuid, primary key)
      - `hashtag` (text, the hashtag name)
      - `platform` (text, source platform: twitter, instagram, tiktok)
      - `tweet_count` (integer, number of mentions/uses)
      - `engagement_rate` (numeric, engagement percentage)
      - `rank` (integer, ranking position)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `trending_hashtags` table
    - Add policy for public read access (trending hashtags are public data)
*/

CREATE TABLE IF NOT EXISTS trending_hashtags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  hashtag text NOT NULL,
  platform text NOT NULL,
  tweet_count integer DEFAULT 0,
  engagement_rate numeric DEFAULT 0,
  rank integer NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE trending_hashtags ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public read access to trending hashtags"
  ON trending_hashtags
  FOR SELECT
  TO public
  USING (true);

CREATE INDEX IF NOT EXISTS idx_trending_hashtags_platform ON trending_hashtags(platform);
CREATE INDEX IF NOT EXISTS idx_trending_hashtags_rank ON trending_hashtags(rank);
