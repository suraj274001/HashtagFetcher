import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const supabaseUrl = Deno.env.get("SUPABASE_URL") || "";
const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";

const supabase = createClient(supabaseUrl, supabaseServiceKey);

interface TrendingHashtag {
  hashtag: string;
  platform: string;
  tweet_count: number;
  engagement_rate: number;
  rank: number;
}

const mockTrendingData: { [key: string]: TrendingHashtag[] } = {
  twitter: [
    { hashtag: "#AI", platform: "twitter", tweet_count: 245000, engagement_rate: 8.5, rank: 1 },
    { hashtag: "#WebDevelopment", platform: "twitter", tweet_count: 198000, engagement_rate: 7.2, rank: 2 },
    { hashtag: "#React", platform: "twitter", tweet_count: 156000, engagement_rate: 6.9, rank: 3 },
    { hashtag: "#JavaScript", platform: "twitter", tweet_count: 142000, engagement_rate: 6.1, rank: 4 },
    { hashtag: "#TypeScript", platform: "twitter", tweet_count: 128000, engagement_rate: 5.8, rank: 5 },
  ],
  instagram: [
    { hashtag: "#FashionTrends", platform: "instagram", tweet_count: 890000, engagement_rate: 12.3, rank: 1 },
    { hashtag: "#DesignInspo", platform: "instagram", tweet_count: 756000, engagement_rate: 11.1, rank: 2 },
    { hashtag: "#CreativeLife", platform: "instagram", tweet_count: 634000, engagement_rate: 10.2, rank: 3 },
    { hashtag: "#ArtistsOnInstagram", platform: "instagram", tweet_count: 512000, engagement_rate: 9.5, rank: 4 },
    { hashtag: "#PhotographyLove", platform: "instagram", tweet_count: 478000, engagement_rate: 8.9, rank: 5 },
  ],
  tiktok: [
    { hashtag: "#ForYouPage", platform: "tiktok", tweet_count: 5200000, engagement_rate: 15.4, rank: 1 },
    { hashtag: "#TikTokChallenge", platform: "tiktok", tweet_count: 4100000, engagement_rate: 14.2, rank: 2 },
    { hashtag: "#DanceChallenge", platform: "tiktok", tweet_count: 3800000, engagement_rate: 13.8, rank: 3 },
    { hashtag: "#FYP", platform: "tiktok", tweet_count: 3200000, engagement_rate: 13.1, rank: 4 },
    { hashtag: "#Trending", platform: "tiktok", tweet_count: 2900000, engagement_rate: 12.5, rank: 5 },
  ],
};

async function fetchAndStoreTrendingHashtags(platform?: string) {
  try {
    const platforms = platform ? [platform] : Object.keys(mockTrendingData);

    for (const plat of platforms) {
      const trendingData = mockTrendingData[plat] || [];

      // Delete old data for this platform
      await supabase.from("trending_hashtags").delete().eq("platform", plat);

      // Insert new trending data
      const { error } = await supabase
        .from("trending_hashtags")
        .insert(
          trendingData.map((item) => ({
            hashtag: item.hashtag,
            platform: item.platform,
            tweet_count: item.tweet_count,
            engagement_rate: item.engagement_rate,
            rank: item.rank,
          }))
        );

      if (error) {
        throw error;
      }
    }

    return { success: true, message: "Trending hashtags updated successfully" };
  } catch (error) {
    console.error("Error fetching trending hashtags:", error);
    throw error;
  }
}

async function getTrendingHashtags(platform?: string) {
  try {
    let query = supabase.from("trending_hashtags").select("*").order("rank", { ascending: true });

    if (platform) {
      query = query.eq("platform", platform);
    }

    const { data, error } = await query;

    if (error) {
      throw error;
    }

    return data || [];
  } catch (error) {
    console.error("Error getting trending hashtags:", error);
    throw error;
  }
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const url = new URL(req.url);
    const action = url.searchParams.get("action");
    const platform = url.searchParams.get("platform");

    if (action === "fetch") {
      const result = await fetchAndStoreTrendingHashtags(platform || undefined);
      return new Response(JSON.stringify(result), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      });
    }

    const trendingHashtags = await getTrendingHashtags(platform || undefined);
    return new Response(JSON.stringify(trendingHashtags), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json",
      },
    });
  } catch (error) {
    console.error("Function error:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});
